<template>
  <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" />
</template>

<script setup>
</script>
